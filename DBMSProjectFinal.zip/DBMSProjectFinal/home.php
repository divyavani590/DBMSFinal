<html>  
<head>
<title>ICTYA Collections</title>
<link rel="stylesheet" href="style.css" />
</head>
<body>
<?php include('header.php'); ?>
<div class="bg">
<br><br><br><br><br><br><br><br><br><br><br>
<font  color="#C70039" face="courier" size= "30"><i><b>
&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Welcome to ICTYA Collections</font></i></b>
<br><br><br><br><br><br><br><br><br><br><br>

<?php include('footer.php') ?>
</body>
</div>
</html>