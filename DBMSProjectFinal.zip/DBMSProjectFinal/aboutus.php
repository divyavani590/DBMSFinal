<html>
<head>

<link rel="stylesheet" href="style.css" />

</head>
<?php include('header.php')?>
<div>
<body background="images/bundles-winter.png" opacity:0.5;></div>
<div  style="background-color:#FFFFFF">
<h1> <font face="courier" color="#2BCDD2"><center>ICTYA Collections: A season of Opulence </center></font></h1>
<p>ICTYA proudly presents to you our new Autumn/Winter Collection 2018. The collection displays new ideas, new inspiration, colours, materials, and textiles. Interesting designs and diversity in look are mixed with a variety of materials to contribute to the signature aesthetic life.</p>

<p>As the temperature slowly begins to drop and the days are getting colder, we aim for providing the best outfit for all ages of people with inbuilt characteristics of the winter clothes.</p>

<p>We welcome natural materials and finishes with an authentic look.</p> 

<p>The outfit make you feel light and warmth and ofcourse beauty inaddition.</p>

<p>Indulge yourself in styles that echo the finest european traditions. Rich fabrics, saturated colors and brilliant details combine in a winter collection of modern elegance.</p>

</p>

<?php include('footer.php') ?>
</div>
</body>


</html>