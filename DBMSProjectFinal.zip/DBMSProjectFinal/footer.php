<div>

<footer>
	<div style="float:left;">&copy; Copyright Winter sales,Inc</div>    <div style="float:right;">Contact us at ictya@gmail.com</div>
    <div class="clear:both;"></div>
</footer>
</div>